import lgpio as GPIO
import time
import cv2
from ultralytics import YOLO
from pygame import mixer 
from gtts import gTTS  

# Here are converting in English Language  
language = 'ar'  

#GPIO.setmode(GPIO.BCM)
#GPIO.setwarnings(False)

Trig = 23
Echo = 24

#GPIO.setup(Trig, GPIO.OUT)
#GPIO.setup(Echo, GPIO.IN)

#GPIO.output(Trig, False)
h = GPIO.gpiochip_open(0)
GPIO.gpio_claim_output(h, Trig)
GPIO.gpio_claim_input(h, Echo)
print("Waiting for sensor ...")
time.sleep(2)

# Load a model
model = YOLO('epochs30.pt')  # pretrained YOLOv8n model

#init sounds
mixer.init()

classes_en = {"car":"car", "person":"person", "bus":"bus", "stairs":"stairs","Pothole": "Pothole"}
classes_ar = {"car":"سيارة", "person":"شخص", "bus":"باص", "stairs":"سلالم", "Pothole":"حفرة"}

def getDistance():
    GPIO.gpio_write(h, Trig, 1)
    time.sleep(0.00001)
    GPIO.gpio_write(h, Trig, 0)
    pulse_start = 0
    while GPIO.gpio_read(h, Echo) == 0:
       pulse_start = time.time()
    
    pulse_end = 0
    while GPIO.gpio_read(h, Echo) == 1:
       pulse_end = time.time()
    
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)
    
    print("Distance:" + str(distance) + "cm")
    #GPIO.cleanup()  
    return distance

# speak the class name
def speak(classname):
    # get the distance
    distance = getDistance()
    if language == "en":
        text_val = classes_en[classname] + " on distance " + str(distance) + " cm"
    if language == "ar":
        text_val = classes_ar[classname]  + " على مسافة " + str(distance) + " سنتيمتر"
    print(text_val)
        
    obj = gTTS(text=text_val, lang=language, slow=False)
    obj.save("object.mp3")  
    mixer.music.load("object.mp3")
    mixer.music.play()
    time.sleep(8)
    mixer.music.unload() 

    
# define a video capture object 
vid = cv2.VideoCapture(0) 
while(True): 
    # Capture the video frame 
    # by frame 
    ret, frame = vid.read() 

    if not ret:
        print("Check your camera!")
        break

    frame = cv2.flip(frame, 1)
    
    # Run batched inference on a list of frame
    results = model([frame])  # return a list of Results objects
   
    # Process results list
    for result in results:
        boxes = result.boxes  # Boxes object for bounding box outputs
        names = result.names
        classname = ""
        for box in boxes.cls:
            classname = names[int(box.item())]
            speak(classname)
        result.save(filename='result.jpg')  # save to disk
        
    frame = cv2.imread('result.jpg')


    # Display the resulting frame 
    cv2.imshow('Object viewer', frame) 
      
    # the 'q' button is set as the 
    # quitting button you may use any 
    # desired button of your choice 
    if cv2.waitKey(1) & 0xFF == ord('q'): 
        break
  
# After the loop release the cap object 
vid.release() 
# Destroy all the windows 
cv2.destroyAllWindows() 
