import sounddevice as sd
import soundfile as sf
import openai
import requests
import re
from colorama import Fore, Style, init
from gtts import gTTS
import os

# Initialize colorama for colored terminal output
init()

def open_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as infile:
        return infile.read().strip()

# Read API keys from text files
api_key = open_file('openaiapikey2.txt')

# Set the OpenAI API key
openai.api_key = api_key

# Initialize conversation and chatbot data
conversation1 = []
chatbot1 = open_file('chatbot1.txt')

def chatgpt(api_key, conversation, chatbot, user_input, temperature=0.9, frequency_penalty=0.2, presence_penalty=0):
    conversation.append({"role": "user", "content": user_input})
    messages_input = conversation.copy()
    prompt = [{"role": "system", "content": chatbot}]
    messages_input.insert(0, prompt[0])
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo-0613",
        temperature=temperature,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        messages=messages_input
    )
    chat_response = completion['choices'][0]['message']['content']
    conversation.append({"role": "assistant", "content": chat_response})
    return chat_response

def text_to_speech(text):
    tts = gTTS(text=text, lang='ar')
    tts.save("output.mp3")
    
    # Use os.system to play the sound file
    if os.name == 'nt':  # For Windows
        os.system("start output.mp3")

def print_colored(agent, text):
    agent_colors = {
        "Nour:": Fore.YELLOW,
    }
    color = agent_colors.get(agent, "")
    print(color + f"{agent}: {text}" + Style.RESET_ALL, end="")

def record_and_transcribe(duration=8, fs=44100):
    print('Recording...')
    myrecording = sd.rec(int(duration * fs), samplerate=fs, channels=2)
    sd.wait()
    print('Recording complete.')
    filename = 'myrecording.wav'
    sf.write(filename, myrecording, fs)
    with open(filename, "rb") as file:
        response = openai.Audio.transcribe(
            model="whisper-1",
            file=file
        )
    transcription = response['text']
    return transcription

while True:
    try:
        user_message = record_and_transcribe()
        response = chatgpt(api_key, conversation1, chatbot1, user_message)
        print_colored("Nour:", f"{response}\n\n")
        user_message_without_generate_image = re.sub(r'(Response:|Narration:|Image: generate_image:.*|)', '', response).strip()
        text_to_speech(user_message_without_generate_image)
    except Exception as e:
        print(f"An error occurred: {e}")

