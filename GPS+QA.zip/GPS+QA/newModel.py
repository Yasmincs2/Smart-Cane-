
import requests
import cv2
from transformers import ViltProcessor, ViltForQuestionAnswering
import torch
import speech_recognition as sr
from gtts import gTTS
from pydub import AudioSegment
import pyaudio
import wave
from pydub.playback import play
import os
import sounddevice as sd
import soundfile as sf


# Load the pre-trained VQA model and processor from Hugging Face
model_name = "dandelin/vilt-b32-finetuned-vqa"
processor = ViltProcessor.from_pretrained(model_name)
model = ViltForQuestionAnswering.from_pretrained(model_name)

  
# Create a VideoCapture object to capture video
cap = cv2.VideoCapture(0)

# Read the current frame from the video stream
ret, frame = cap.read()

# Flip the frame horizontally
frame = cv2.flip(frame, 1)

# Display the resulting frame
cv2.imshow('Object viewer', frame)

# Exit when 'q' key is pressed
if cv2.waitKey(1) & 0xFF == ord('q'):
    cap.release()
    cv2.destroyAllWindows()


# Function to record audio from the microphone
def record_audio():
    fs = 44100  # Sample rate
    duration = 5  # Duration in seconds

    print("Recording audio...")

    audio = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()  # Wait until recording is finished

    print("Audio recording complete.")

    return audio, fs

# Function to save audio as a WAV file
def save_audio(audio, fs, filename):
    sf.write(filename, audio, fs)



def recognize_speech_from_audio_file(audio_file):
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_file) as source:
        audio = recognizer.record(source)
        try:
            question = recognizer.recognize_sphinx(audio)
            print(f"Recognized question: {question}")
            return question
        except sr.UnknownValueError:
            print("Speech recognition could not understand audio")
            return None
        except sr.RequestError as e:
            print(f"Could not request results from speech recognition service; {e}")
            return None
 

# Function to convert text to speech and play the audio
def text_to_speech(text):
    tts = gTTS(text)
    tts.save("answer.mp3")
    answer_audio = AudioSegment.from_file("answer.mp3", format="mp3", ffmpeg=os.path.abspath("ffprobe.exe"))
    play(answer_audio)


   

# Start the interaction loop
while True:
    # Record audio from the microphone
    audio, fs = record_audio()

    # Save the recorded audio as a WAV file
    audio_file = "question.wav"
    save_audio(audio, fs, audio_file)

    # Recognize speech from the recorded audio file
    question = recognize_speech_from_audio_file(audio_file)

    # Check if the user wants to exit
    if question.lower() == "stop":
        print("Thank you! Exiting the model.")
        break

    # Prepare inputs
    inputs = processor(frame, question, return_tensors="pt")

    # Forward pass to get logits
    outputs = model(**inputs)
    logits = outputs.logits

    # Get the predicted answer id
    answer_idx = logits.argmax(-1).item()

    # Convert the answer id to the corresponding string
    answer = model.config.id2label[answer_idx]

    # Print the answer
    print(f"Question: {question}")
    print(f"Answer: {answer}")
    print()

    # Convert the answer to speech and play the audio
    #text_to_speech(question)
    text_to_speech(answer)
