import webbrowser

def open_map(latitude, longitude):
    # إنشاء رابط جوجل ماب باستخدام الإحداثيات وفتحه في المتصفح الافتراضي
    url = f"https://www.google.com/maps/search/?api=1&query={latitude},{longitude}"
    webbrowser.open_new_tab(url)

def get_nearby_places():
    places = {
        "أقرب كوفي": {"المكان": "دانكن", "المسافة": "دقيقتان (180 م)", "الإحداثيات": (24.854038, 46.712919)},
        "أقرب مطعم": {"المكان": "كويزنس", "المسافة": "٢ دقيقتان (170 م)", "الإحداثيات": (24.854089, 46.713001)},
        "أقرب مجمع": {"المكان": "واجهة روشن", "المسافة": "ساعة و ٥٧ دقيقة (8.6 كم)", "الإحداثيات": (24.854505, 46.712919)},
        "أقرب مول": {"المكان": "بارك أفنيو", "المسافة": "ساعتان و ٣٣ دقيقة (10.5 كم)", "الإحداثيات": (24.774852, 46.733501)},
        "أقرب محطة قطار": {"المكان": "محطة قطار S1", "المسافة": "٤ دقائق (300 م)", "الإحداثيات": (24.854971, 46.712919)},
        "أقرب مستشفى": {"المكان": "مستشفى الملك عبدالله الجامعي", "المسافة": "٥٧ دقيقة (4.2 كم)", "الإحداثيات": (24.850000, 46.721000)}
    }
    return places

def display_places():
    places = get_nearby_places()
    for place_name, place_details in places.items():
        print(f"{place_name}: {place_details['المكان']} على مسافة {place_details['المسافة']}")

def ask_for_more_help():
    more_help = input("هل تريد مساعدة أخرى؟ (نعم/لا شكراً): ")
    if more_help.lower() == "نعم":
        return True
    else:
        print("شكراً، تم إغلاق البرنامج.")
        return False

def main():
    while True:
        # طلب الإدخال من المستخدم
        location_input = input("أدخل 'أين أنا' لتحديد موقعك الحالي أو 'الأماكن القريبه' لعرض الأماكن القريبه :")

        if location_input.lower() == "أين أنا":
            # 
            latitude = 24.854010
            longitude =  46.712920
            print("في الرياض , أكادمية طويق")
            open_map(latitude, longitude)
        elif location_input.lower() == "الأماكن القريبه":
            display_places()
        else:
            places = get_nearby_places()
            if location_input in places:
                place_details = places[location_input]
                print(f"تم العثور على {location_input}: {place_details['المكان']} على مسافة {place_details['المسافة']}")
                latitude, longitude = place_details['الإحداثيات']
                confirmation = input(f"هل تريد الذهاب إلى {location_input}? (نعم/لا): ")
                if confirmation.lower() == "نعم":
                    open_map(latitude, longitude)
                else:
                    print("تم إلغاء العملية.")
            else:
                print("خطأ: الإدخال غير موجود في القائمة.")

        # سؤال المستخدم إذا كان يحتاج لمزيد من المساعدة
        if not ask_for_more_help():
            break

if __name__ == "__main__":
    main()


from talk import main as talk_main

if __name__ == "__main__":
    talk_main()

    
